package com.example.financialapp.domain;

public enum TransactionType {
    DEPOSIT, WITHDRAWAL, TRANSFER
}
