package com.example.financialapp.domain;

public enum AccountType {
    SAVINGS, CHECKING
}
