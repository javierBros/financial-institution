package com.example.financialapp.domain;

public enum AccountStatus {
    ACTIVE, INACTIVE, CANCELED
}
